#!/bin/bash

if [[ $(basename $0) = "template_task.sh" ]]; then
    echo "Я бригадир, сам не работаю."    	
    exit 1
fi

pipe="/tmp/run/cuckoo.pid"
file="report_$(basename $0 .sh).log"
touch $file
echo "$(date) [$$] Скрипт запущен" >> $file

request="$0[$$]: how much time do i have?"
echo $request > $pipe
read -r response < $pipe

sleep $response
echo "$(date) [$$] Скрипт завершился, работал $reponse секунд." >> $file
