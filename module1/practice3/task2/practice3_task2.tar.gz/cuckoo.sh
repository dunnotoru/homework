#!/bin/bash

trap "echo $(date) Shutdown! >> cuckoo.log; exit" SIGTERM

pipe="/tmp/run/cuckoo.pid"

mkdir -p /tmp/run/
mkfifo $pipe

echo $(date) Startup! > cuckoo.log 
regex=".*\[[0-9]+\]: how much time do i have\?"
while true; do
  read -r str < $pipe
  if [[ "$str" =~ $regex ]]; then
      name=$(echo $str | sed 's/\(.*\)\[.*/\1/')
      pid=$(echo $str | sed 's/.*\[\([0-9]*\)\].*/\1/')
      n=$(($RANDOM % 9 + 2))
      echo $n > $pipe
      echo "$(date) $name[$pid] $n" >> cuckoo.log
  fi
done
