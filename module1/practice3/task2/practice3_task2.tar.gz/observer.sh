#!/bin/bash

conf="observer.conf"
touch $conf

while IFS= read -r line; do
    echo $line
    pid=$(pgrep -f $line)
    echo $pid
    if [[ -z $pid ]]; then
        nohup $line & &>/dev/null
        echo "Start $line" >> "observer.log"
    fi
done < $conf 
